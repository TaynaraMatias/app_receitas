import 'package:flutter/material.dart';
import 'fooderlich_theme.dart';
import 'home.dart';
import 'package:provider/provider.dart';
import 'models/models.dart';

void main() {
  runApp(const Fooderlich());
}

class Fooderlich extends StatelessWidget {
  const Fooderlich({super.key});
  @override
  Widget build(BuildContext context) {

    //1
    home: MultiProvider(
      providers:[
        //2
        ChangeNotifierProvider(create: (context)=>TabManager()),
        ChangeNotifierProvider(create: (context)=> GroceryManager()),
      ],
      child: const Home(),
    ),

    final theme = FooderlichTheme.light();
    return MaterialApp(
      theme: theme,
      title: 'Receitas Boas',
      home: const Home(),
    );
  }
}
